# perceptron

_Multi layer perceptron (a.k.a. neural network) implemented from scratch in C++_

## Install

You can just copy the source and headers file from [src](/src) and [include](/include) into your own project.

## Usage

To use the library, 

```cpp
// TODO
```

## References

- [🗄️ tsoding/perceptron](https://github.com/tsoding/perceptron)
- [📼 3Blue1Brown - Neural Networks](https://www.3blue1brown.com/topics/neural-networks)